const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, ImageRun, AlignmentType, BorderStyle } = require("docx");

const body = (lead, text) => new Paragraph({
  spacing: { after: 120, line: 259 }, alignment: AlignmentType.LEFT,
  children: [new TextRun({ text: lead + " ", bold: true, color: "16324F" }), new TextRun(text)],
});

const doc = new Document({
  styles: { default: { document: { run: { font: "Calibri", size: 22 } } } },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1000, bottom: 900, left: 1150, right: 1150 } } },
    children: [
      new Paragraph({ spacing: { after: 40 }, children: [new TextRun({ text: "Forecasting U.S. Monthly Electricity Demand", bold: true, size: 32, font: "Cambria", color: "16324F" })] }),
      new Paragraph({ spacing: { after: 140 }, border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "E8793A", space: 4 } },
        children: [new TextRun({ text: "Recommendation memo for the management team  |  November 23, 2026  |  Data: U.S. Energy Information Administration", size: 18, color: "5A6672" })] }),

      body("Forecast and conclusion.",
        "We recommend planning for about 4,150 billion kWh of U.S. electricity sales over the next 12 months (August 2026 to July 2027), 1.5% above the last 12 months. Demand should peak in July 2027 near 411 billion kWh, with an 80% range of 395 to 427. Because July 2026 already reached 415, we suggest planning summer capacity toward the upper end of that range rather than the single point forecast. As a check, the model's August 2026 forecast (409.6) came within 0.7% of the figure EIA has since published (412.6), which was not used to fit the model."),

      new Paragraph({ spacing: { after: 110 }, alignment: AlignmentType.CENTER, children: [new ImageRun({ type: "png", data: fs.readFileSync("figs/forecast_memo.png"), transformation: { width: 560, height: 179 },
        altText: { title: "Forecast", description: "Actual monthly U.S. electricity sales and SARIMA forecast with 80% interval to July 2027", name: "forecast" } })] }),

      body("Methodology.",
        "We compared four models: a seasonal naive benchmark (repeat last year), the same benchmark with a yearly drift, Holt-Winters exponential smoothing, and a seasonal ARIMA (SARIMA) model. Each was tested on three separate 12-month periods it had not seen, ending July 2023, 2024 and 2025. We ranked them by RMSE, which penalizes large misses such as a missed summer peak, and also report MAPE (average percentage error). SARIMA(1,1,1)(0,1,1)[12], fitted to log sales, had the lowest average error: RMSE 8.2 billion kWh and MAPE 1.9%, against 8.6 and 2.1% for Holt-Winters and 9.7 and 2.5% for the benchmark. Its residuals passed the Ljung-Box white-noise test (p = 0.89); Holt-Winters did not (p = 0.014)."),

      body("Data and exploration insights.",
        "The data are monthly total U.S. retail electricity sales from the EIA Monthly Energy Review (Table 7.6), January 2001 to July 2026: 307 months with no gaps. EIA is the official source, and 31 months that also appear in its Electric Power Monthly agree within 1%. The series is very seasonal (July peak, April low) and its trend was nearly flat from 2007 to 2019 (+0.1% a year) before rising about 1.05% a year from 2019 to 2025. Autocorrelation plots show the series needs one regular and one seasonal difference to be stationary, which the chosen model includes. The 2020 COVID dip (second-quarter sales down 3.9% year on year) is a visible outlier."),

      body("Limitations and recommendations.",
        "The forecast is weather-normal: a hot summer or cold winter can move a month well outside the central path, and the model cannot anticipate new large loads such as data centers or electrification. EIA's most recent values are preliminary and get revised, and our test uses only three yearly windows. We recommend (1) adopting this SARIMA model for monthly planning and refitting it with each EIA release, (2) planning peak capacity to the upper band, and (3) in the next round adding weather (degree-day) and large-load drivers, forecasting by customer sector, and testing a combination of models."),
    ],
  }],
});
Packer.toBuffer(doc).then((b) => { fs.writeFileSync("electricity_forecast_memo.docx", b); console.log("ok"); });

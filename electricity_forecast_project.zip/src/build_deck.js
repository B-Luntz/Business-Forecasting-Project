const pptxgen = require("pptxgenjs");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");
const D = require("./deckdata.json");
const R = require("./results.json");

const THEME = {
  name: "Grid Demand", headFontFace: "Cambria", bodyFontFace: "Calibri",
  colors: { dk1: "1B2733", lt1: "FFFFFF", dk2: "16324F", lt2: "EEF2F6", accent1: "E8793A", accent2: "2A9D8F",
            accent3: "16324F", accent4: "8A94A0", accent5: "C0392B", accent6: "B08D57", hlink: "2A6EBB", folHlink: "7A5C99" },
};
const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
pres.title = "Forecasting U.S. Monthly Electricity Demand";
const C = pres.SchemeColor;
const HEX = { navy: "16324F", orange: "E8793A", teal: "2A9D8F", grey: "8A94A0", gold: "B08D57", red: "C0392B" };

// ---------- layouts ----------
pres.defineSlideMaster({
  title: "TITLE_DARK",
  objects: [
    { rect: { x: 0, y: 0, w: 10, h: 5.625, fill: { color: C.text2 } } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.35, w: 8.6, h: 1.5, fontSize: 38, bold: true, color: C.background1, align: "left", valign: "bottom", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "body", type: "body", x: 0.7, y: 3.05, w: 8.6, h: 1.1, fontSize: 18, color: C.background2, align: "left", valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "CONTENT",
  background: { color: "FFFFFF" },
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.25, w: 9, h: 0.9, fontSize: 24, bold: true, color: C.text2, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: "U.S. monthly electricity demand forecast  |  Source: EIA Monthly Energy Review, Table 7.6", options: { x: 0.5, y: 5.25, w: 7.5, h: 0.25, fontSize: 10, color: C.text1, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.25, w: 0.5, h: 0.25, fontSize: 10, color: C.text1, align: "right" },
});

// ---------- helpers ----------
const bullets = (items, o = {}) => items.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < items.length - 1, paraSpaceAfter: 8 } }));
function textBox(s, runs, x, y, w, h, opts = {}) {
  s.addText(runs, Object.assign({ x, y, w, h, fontSize: 14, color: C.text1, valign: "top", margin: 0, isTextBox: true }, opts));
}
function card(s, x, y, w, h, big, label, name) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: C.background2 }, line: { color: C.background2 }, rectRadius: 0.12, objectName: name + " card" });
  s.addText(big, { x: x + 0.15, y: y + 0.12, w: w - 0.3, h: h * 0.45, fontSize: 26, bold: true, color: C.accent1, fontFace: "Cambria", valign: "middle", margin: 0, isTextBox: true, objectName: name + " value" });
  s.addText(label, { x: x + 0.15, y: y + h * 0.55, w: w - 0.3, h: h * 0.4, fontSize: 14, color: C.text1, valign: "top", margin: 0, isTextBox: true, objectName: name + " label" });
}
function chartStyle() {
  return { catAxisLabelFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt", legendFontFace: "+mn-lt", titleFontFace: "+mn-lt",
    catAxisLabelFontSize: 11, valAxisLabelFontSize: 11, legendFontSize: 11, catAxisLabelColor: "1B2733", valAxisLabelColor: "1B2733",
    valGridLine: { color: "D9DEE4", size: 0.5 }, catGridLine: { style: "none" }, showLegend: true, legendPos: "b" };
}
const f1 = (v) => v.toFixed(1), f2 = (v) => v.toFixed(2);
function slide(title, section) { const s = pres.addSlide({ masterName: "CONTENT", sectionTitle: section }); s.addText(title, { placeholder: "title" }); return s; }
function header(cells) { return cells.map((t) => ({ text: t, options: { bold: true, color: C.background1, fill: { color: C.text2 }, align: "center", valign: "middle" } })); }

// ---------- 1. Title ----------
pres.addSection({ title: "Intro" });
let s = pres.addSlide({ masterName: "TITLE_DARK", sectionTitle: "Intro" });
s.addText("Forecasting U.S. Monthly Electricity Demand", { placeholder: "title" });
s.addText("Time series model comparison on EIA retail sales, 2001 to 2026, and a 12-month forecast to July 2027", { placeholder: "body" });

// ---------- 2. Problem ----------
pres.addSection({ title: "Problem and data" });
s = slide("The problem: plan for the summer peak as demand grows", "Problem and data");
card(s, 0.5, 1.3, 2.85, 1.45, "4,058 bn kWh", "Electricity sold to U.S. customers in 2025", "stat1");
card(s, 3.575, 1.3, 2.85, 1.45, "+1.05% / yr", "Growth 2019 to 2025, versus +0.10% / yr from 2007 to 2019", "stat2");
card(s, 6.65, 1.3, 2.85, 1.45, "~41 bn kWh", "Size of a 1% forecast miss on one year of demand", "stat3");
textBox(s, [
  { text: "What we forecast: ", options: { bold: true } },
  { text: "total monthly U.S. retail electricity sales for the next 12 months (Aug 2026 to Jul 2027).", options: { breakLine: true } },
  { text: " ", options: { fontSize: 6, breakLine: true } },
  { text: "Why it matters: ", options: { bold: true } },
  { text: "demand is strongly seasonal and has recently started growing. Capacity, fuel purchases and maintenance windows are set against the summer peak, so both under- and over-forecasting are costly.", options: { breakLine: true } },
  { text: " ", options: { fontSize: 6, breakLine: true } },
  { text: "Decision supported: ", options: { bold: true } },
  { text: "which model management should use for monthly demand planning, and what range to plan to." },
], 0.5, 3.0, 9, 2.1, { fontSize: 15 });

// ---------- 3. Data ----------
s = slide("The data: official EIA series, reliable with two caveats", "Problem and data");
const rows = [
  ["Source", "EIA Monthly Energy Review, Table 7.6 (Oct 2026 release); based on survey Form EIA-861M"],
  ["Series", "Electricity sales to ultimate customers, all sectors (billion kWh per month)"],
  ["Sample", "Jan 2001 to Jul 2026, 307 monthly points, no gaps (file goes back to 1973)"],
];
rows.forEach((r, i) => {
  const y = 1.4 + i * 1.15;
  s.addText(r[0], { x: 0.5, y, w: 1.1, h: 0.65, fontSize: 16, bold: true, color: C.text2, valign: "top", margin: 0, isTextBox: true });
  s.addText(r[1], { x: 1.6, y, w: 3.4, h: 1.0, fontSize: 15, color: C.text1, valign: "top", margin: 0, isTextBox: true });
});
s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.3, y: 1.3, w: 4.2, h: 3.75, fill: { color: C.background2 }, line: { color: C.background2 }, rectRadius: 0.12, objectName: "reliability card" });
textBox(s, [
  { text: "Is it reliable?", options: { bold: true, fontSize: 16, color: C.text2, breakLine: true } },
  { text: "Cross-check passed: ", options: { bold: true, bullet: true } },
  { text: "31 months also in EIA's Electric Power Monthly agree within 1.0% (average gap 0.25%)", options: { breakLine: true } },
  { text: "Caveat 1: ", options: { bold: true, bullet: true } },
  { text: "2026 values are preliminary estimates and can be revised", options: { breakLine: true } },
  { text: "Caveat 2: ", options: { bold: true, bullet: true } },
  { text: "one-off shocks are in the data (COVID: Q2 2020 sales fell 3.9% year on year)" },
], 5.5, 1.45, 3.8, 3.5, { paraSpaceAfter: 6 });

// ---------- 4. Methodology ----------
pres.addSection({ title: "Method" });
s = slide("The methodology: four models, three test years", "Method");
const models = [
  ["Seasonal naive", "Repeat the same month last year. The benchmark."],
  ["Seasonal naive + drift", "Same, plus the average yearly level change."],
  ["Holt-Winters (ETS)", "Smoothed level and seasonal factors, chosen by AICc."],
  ["SARIMA", "Differenced ARMA with seasonal terms, on log sales."],
];
models.forEach((m, i) => {
  const y = 1.3 + i * 0.95;
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y, w: 4.5, h: 0.82, fill: { color: C.background2 }, line: { color: C.background2 }, rectRadius: 0.1, objectName: "model " + (i + 1) });
  s.addText(m[0], { x: 0.65, y: y + 0.06, w: 4.2, h: 0.3, fontSize: 14, bold: true, color: C.text2, margin: 0, isTextBox: true });
  s.addText(m[1], { x: 0.65, y: y + 0.38, w: 4.2, h: 0.36, fontSize: 12, color: C.text1, margin: 0, isTextBox: true });
});
textBox(s, [
  { text: "How we choose", options: { bold: true, fontSize: 16, color: C.text2, breakLine: true } },
  { text: "RMSE (primary): ", options: { bold: true, bullet: true } },
  { text: "in kWh, punishes big misses such as a missed peak", options: { breakLine: true } },
  { text: "MAPE (reported): ", options: { bold: true, bullet: true } },
  { text: "a plain percentage for management", options: { breakLine: true } },
  { text: "Test design: ", options: { bold: true, bullet: true } },
  { text: "three 12-month holdouts (ending Jul 2023, 2024, 2025), average the errors", options: { breakLine: true } },
  { text: "Then: ", options: { bold: true, bullet: true } },
  { text: "Ljung-Box residual tests; AIC only within a model family" },
], 5.3, 1.3, 4.2, 3.8, { paraSpaceAfter: 6 });

// ---------- 5. Exploration: series ----------
pres.addSection({ title: "Exploration" });
s = slide("Exploration: strong seasonality, rising since 2020", "Exploration");
s.addImage({ path: "figs/series.png", x: 0.5, y: 1.3, w: 6.4, h: 3.76, altText: "Monthly U.S. electricity sales 2001 to 2026 with 12-month moving average" });
textBox(s, bullets([
  "Flat trend 2007 to 2019, then a clear climb",
  "Summer peaks now reach 415 bn kWh",
  "COVID dip in 2020 is a one-off outlier",
]), 7.2, 1.4, 2.3, 3.5, { paraSpaceAfter: 10 });

// ---------- 6. STL ----------
s = slide("Decomposition: seasonality dominates", "Exploration");
s.addImage({ path: "figs/stl.png", x: 0.5, y: 1.25, w: 5.0, h: 3.82, altText: "STL decomposition of log sales into trend, seasonal and remainder" });
textBox(s, bullets([
  "Seasonal strength 0.96 and trend strength 0.84 (1.0 is maximum)",
  "Remainder stays within about 5% of the level",
  "A seasonal model with a trend term is needed",
]), 6.0, 1.4, 3.5, 3.5, { paraSpaceAfter: 10 });

// ---------- 7. Seasonal ----------
s = slide("Seasonal pattern: July peak, April trough, and rising", "Exploration");
s.addImage({ path: "figs/seasonal.png", x: 0.5, y: 1.25, w: 5.6, h: 3.92, altText: "Monthly profile by year, 2001 to 2026" });
textBox(s, bullets([
  "Peak in July, trough in April, every year",
  "Newer years (yellow) sit above older ones in all months",
  "Summer 2026 is the highest on record at 415 bn kWh",
]), 6.4, 1.4, 3.1, 3.5, { paraSpaceAfter: 10 });

// ---------- 8. ACF ----------
s = slide("ACF and PACF point to SARIMA with d=1, D=1", "Exploration");
s.addImage({ path: "figs/acf_explore.png", x: 0.5, y: 1.2, w: 9, h: 2.85, altText: "ACF of log series, ACF and PACF after differencing" });
textBox(s, bullets([
  "Log series: slowly decaying ACF with spikes at lags 12, 24, 36. Not stationary (ADF p = 0.37).",
  "After d = 1 and D = 1: ADF p < 0.001. Negative spikes at lags 1 and 12 point to MA(1) and seasonal MA(1) terms.",
]), 0.5, 4.2, 9, 0.95, { paraSpaceAfter: 6 });

// ---------- 9. Judgement: holdout ----------
pres.addSection({ title: "Judgement" });
s = slide("Latest 12 months: the drift benchmark is hard to beat", "Judgement");
const H = D.hold;
s.addChart(pres.charts.LINE, [
  { name: "Actual", labels: H.labels, values: H.cols.actual },
  { name: "Seasonal naive", labels: H.labels, values: H.cols["Seasonal naive"] },
  { name: "Naive + drift", labels: H.labels, values: H.cols["Seasonal naive + drift"] },
  { name: "Holt-Winters", labels: H.labels, values: H.cols["Holt-Winters (ETS)"] },
  { name: "SARIMA", labels: H.labels, values: H.cols["SARIMA"] },
], Object.assign(chartStyle(), { x: 0.4, y: 1.25, w: 5.5, h: 3.9, chartColors: [HEX.navy, HEX.grey, HEX.gold, HEX.orange, HEX.teal],
  lineSize: 2, lineDataSymbol: "none", valAxisMinVal: 280, valAxisMaxVal: 420, valAxisMajorUnit: 20, catAxisLabelFrequency: 2,
  showValAxisTitle: true, valAxisTitle: "bn kWh", valAxisTitleFontSize: 11, valAxisTitleColor: "1B2733",
  }));
const M = D.metrics;
const order = ["Seasonal naive", "Seasonal naive + drift", "Holt-Winters (ETS)", "SARIMA"];
const tbl = [header(["Model", "RMSE", "MAPE %"])];
order.forEach((k) => tbl.push([
  { text: k, options: { align: "left" } }, { text: f2(M[k].RMSE), options: { align: "center" } }, { text: f2(M[k].MAPE), options: { align: "center" } }]));
s.addTable(tbl, { x: 6.1, y: 1.35, w: 3.4, colW: [1.7, 0.85, 0.85], fontSize: 12, color: C.text1, border: { type: "solid", color: "D9DEE4", pt: 0.75 }, rowH: 0.4, valign: "middle" });
textBox(s, "One window only: Aug 2025 to Jul 2026. Drift wins here because demand kept growing, but one year is a thin basis for choosing.", 6.1, 3.65, 3.4, 1.5, { fontSize: 14 });

// ---------- 10. Judgement: rolling ----------
s = slide("Across three test years, SARIMA has the lowest error", "Judgement");
const orig = ["Jul 2023", "Jul 2024", "Jul 2025"];
const rk = [["Seasonal naive", HEX.grey], ["Seasonal naive + drift", HEX.gold], ["Holt-Winters (ETS)", HEX.orange], ["SARIMA", HEX.teal]];
s.addChart(pres.charts.BAR, rk.map(([k]) => ({ name: k === "Seasonal naive + drift" ? "Naive + drift" : k === "Holt-Winters (ETS)" ? "Holt-Winters" : k, labels: orig, values: D.rr[k].map((v) => +v.toFixed(1)) })),
  Object.assign(chartStyle(), { x: 0.4, y: 1.25, w: 5.9, h: 3.9, barDir: "col", barGrouping: "clustered", chartColors: rk.map((r) => r[1]),
    showValue: true, dataLabelFontSize: 10, dataLabelFontFace: "+mn-lt", dataLabelColor: "1B2733", dataLabelPosition: "outEnd", dataLabelFormatCode: "0.0",
    showValAxisTitle: true, valAxisTitle: "RMSE, bn kWh (test year ending)", valAxisTitleFontSize: 11, valAxisTitleColor: "1B2733", valAxisMinVal: 0, valAxisMaxVal: 16 }));
const t2 = [header(["Model", "Avg RMSE", "Avg MAPE"])];
order.forEach((k) => t2.push([{ text: k.replace("Seasonal naive + drift", "Naive + drift"), options: { align: "left", bold: k === "SARIMA" } }, { text: f2(D.rrm[k]), options: { align: "center", bold: k === "SARIMA" } }, { text: f2(D.rm[k]), options: { align: "center", bold: k === "SARIMA" } }]));
s.addTable(t2, { x: 6.5, y: 1.35, w: 3.0, colW: [1.3, 0.85, 0.85], fontSize: 12, color: C.text1, border: { type: "solid", color: "D9DEE4", pt: 0.75 }, rowH: 0.4, valign: "middle" });
textBox(s, "Averages over three test years (MAPE in %). Drift was worst in 2023 and best in 2025, so it is unstable. SARIMA is never worst and best on average.", 6.5, 3.6, 3.0, 1.6, { fontSize: 14 });

// ---------- 11. Inference & residuals ----------
s = slide("Residuals: SARIMA passes, Holt-Winters fails", "Judgement");
s.addImage({ path: "figs/residuals.png", x: 0.4, y: 1.25, w: 6.1, h: 3.25, altText: "Residual plot, ACF and histogram for Holt-Winters and SARIMA" });
textBox(s, [
  { text: "SARIMA(1,1,1)(0,1,1)", options: { bold: true, color: C.text2, breakLine: true } },
  { text: "AR(1) 0.51, MA(1) -0.90, seasonal MA -0.89, all p < 0.001", options: { breakLine: true } },
  { text: " ", options: { fontSize: 6, breakLine: true } },
  { text: "Ljung-Box p-values (lag 12 / 24)", options: { bold: true, color: C.text2, breakLine: true } },
  { text: "SARIMA 0.89 / 0.53: white noise", options: { breakLine: true } },
  { text: "Holt-Winters 0.014 / 0.037: fails", options: {} },
], 6.7, 1.35, 2.8, 3.0, { fontSize: 14 });
textBox(s, "Holt-Winters was fitted with no trend term, so it leaves autocorrelated errors. SARIMA residuals are centered with no leftover pattern.", 0.5, 4.6, 9, 0.6, { fontSize: 14 });

// ---------- 12. Recommendation ----------
pres.addSection({ title: "Recommendation" });
s = pres.addSlide({ masterName: "TITLE_DARK", sectionTitle: "Recommendation" });
s.addText([{ text: "Recommended model:", options: { breakLine: true } }, { text: "SARIMA(1,1,1)(0,1,1)[12]" }], { placeholder: "title" });
s.addText("Fitted on log sales. Lowest average error over three test years, and residuals that pass the white-noise test", { placeholder: "body" });
textBox(s, "Selection basis moved from one holdout to three after the single window proved unstable. Both views are shown on slides 9 and 10.", 0.7, 4.3, 8.6, 0.7, { fontSize: 14, color: C.background2 });

// ---------- 13. Forecast ----------
pres.addSection({ title: "Forecast" });
s = slide("Forecast: demand up 1.5%, July 2027 peak near 411", "Forecast");
const FL = D.fc.map((r) => new Date(r[0] + "T00:00:00").toLocaleString("en-US", { month: "short" }));
s.addChart(pres.charts.LINE, [
  { name: "Last 12 months (actual)", labels: FL, values: D.last12 },
  { name: "Forecast Aug 2026 to Jul 2027", labels: FL, values: D.fc.map((r) => r[1]) },
  { name: "80% interval (low)", labels: FL, values: D.fc.map((r) => r[2]) },
  { name: "80% interval (high)", labels: FL, values: D.fc.map((r) => r[3]) },
], Object.assign(chartStyle(), { x: 0.4, y: 1.25, w: 5.9, h: 3.9, chartColors: [HEX.navy, HEX.orange, HEX.grey, HEX.grey], lineSize: 2, lineDataSymbol: "none",
 valAxisMinVal: 260, valAxisMaxVal: 440, valAxisMajorUnit: 20, showValAxisTitle: true, valAxisTitle: "bn kWh per month", valAxisTitleFontSize: 11, valAxisTitleColor: "1B2733" }));
card(s, 6.5, 1.3, 3.0, 1.15, "+1.5%", "Next 12 months: 4,150 bn kWh", "k1");
card(s, 6.5, 2.55, 3.0, 1.15, "411 bn kWh", "Jul 2027 peak (80%: 395 to 427)", "k2");
card(s, 6.5, 3.8, 3.0, 1.3, "-0.7%", "Aug 2026 check: forecast 409.6, actual 412.6", "k3");

// ---------- 14. Implication ----------
s = slide("Implication: plan to the upper band, not the mean", "Forecast");
const imp = [
  ["Base case", "About 4,150 bn kWh over the next 12 months, 1.5% above the last 12. Use for budgets and fuel purchases."],
  ["Peak planning", "Consider sizing summer capacity to the 80% upper bound, about 427 bn kWh. July 2026 already hit 415."],
  ["Monthly refresh", "Refit each month when EIA publishes. Recent months are preliminary and revised."],
];
imp.forEach((r, i) => {
  const x = 0.5 + i * 3.1;
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 1.35, w: 2.9, h: 2.2, fill: { color: C.background2 }, line: { color: C.background2 }, rectRadius: 0.12, objectName: "implication " + (i + 1) });
  s.addText(r[0], { x: x + 0.15, y: 1.5, w: 2.6, h: 0.4, fontSize: 18, bold: true, color: C.accent1, fontFace: "Cambria", margin: 0, isTextBox: true });
  s.addText(r[1], { x: x + 0.15, y: 2.0, w: 2.6, h: 1.5, fontSize: 15, color: C.text1, valign: "top", margin: 0, isTextBox: true });
});
textBox(s, "The point forecast for July 2027 sits slightly below July 2026's actual because the model treats part of last summer's spike as temporary weather. These are weather-normal forecasts.", 0.5, 3.85, 9, 1.2, { fontSize: 16 });

// ---------- 15. Improvements ----------
pres.addSection({ title: "Next steps" });
s = slide("Ideas to improve the forecast", "Next steps");
const ideas = [
  ["Add weather", "Heating and cooling degree days as regressors (SARIMAX) to separate weather from trend."],
  ["Add demand drivers", "Data center load, EV charging and electrification as external variables."],
  ["Forecast by sector", "Model residential, commercial, industrial separately and sum them."],
  ["Combine models", "Average SARIMA with ETS or drift forecasts to reduce risk of one bad fit."],
  ["Handle shocks", "Intervention terms for 2020, and test a shorter post-2010 training window."],
  ["Track revisions", "Evaluate against first-release data and monitor interval coverage over time."],
];
ideas.forEach((r, i) => {
  const col = i % 3, row = Math.floor(i / 3);
  const x = 0.5 + col * 3.1, y = 1.35 + row * 1.95;
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 2.9, h: 1.8, fill: { color: C.background2 }, line: { color: C.background2 }, rectRadius: 0.12, objectName: "idea " + (i + 1) });
  s.addText(r[0], { x: x + 0.15, y: y + 0.12, w: 2.6, h: 0.35, fontSize: 16, bold: true, color: C.text2, fontFace: "Cambria", margin: 0, isTextBox: true });
  s.addText(r[1], { x: x + 0.15, y: y + 0.55, w: 2.6, h: 1.15, fontSize: 14, color: C.text1, valign: "top", margin: 0, isTextBox: true });
});

(async () => {
  await pres.writeFile({ fileName: "electricity_forecast_deck.pptx" });
  await applyTheme("electricity_forecast_deck.pptx", THEME);
  console.log("ok");
})();

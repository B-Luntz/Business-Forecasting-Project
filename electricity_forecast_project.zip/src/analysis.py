"""US monthly electricity retail sales: forecasting analysis (EIA MER Table 7.6)."""
import json, itertools, warnings, sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.seasonal import STL
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.stats.diagnostic import acorr_ljungbox
warnings.filterwarnings("ignore")

SRC = sys.argv[1] if len(sys.argv) > 1 else "Table_7_6_Electricity_End_Use_and_Electric_Vehicle_Use.xlsx"
START, H = "2001-01-01", 12
NAVY, ORANGE, TEAL, GREY, RED = "#16324F", "#E8793A", "#2A9D8F", "#8A94A0", "#C0392B"
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": .25, "font.size": 11})

# ---------- load ----------
raw = pd.read_excel(SRC, sheet_name="Monthly Data", header=None, skiprows=12)
df = raw[[0, 5]].copy(); df.columns = ["date", "y"]
df["date"] = pd.to_datetime(df["date"], errors="coerce")
df["y"] = pd.to_numeric(df["y"], errors="coerce")
df = df.dropna()
full = df.set_index("date")["y"].asfreq("MS") / 1000.0      # billion kWh
y = full[START:]
assert y.isna().sum() == 0
train, test = y.iloc[:-H], y.iloc[-H:]
out = {"n": len(y), "start": str(y.index[0].date()), "end": str(y.index[-1].date()),
       "train_end": str(train.index[-1].date()), "test_start": str(test.index[0].date())}

# ---------- exploration ----------
fig, ax = plt.subplots(figsize=(8, 4.7))
ax.plot(y.index, y, color=NAVY, lw=1.4)
ax.plot(y.rolling(12).mean(), color=ORANGE, lw=2.2, label="12-month moving average")
ax.set_ylabel("Billion kWh per month"); ax.legend(frameon=False, loc="upper left")
fig.tight_layout(); fig.savefig("figs/series.png", dpi=200); plt.close()

stl = STL(np.log(y), period=12, robust=True).fit()
fig, axs = plt.subplots(3, 1, figsize=(8, 6.1), sharex=True)
for a, s, t, c in zip(axs, [stl.trend, stl.seasonal, stl.resid], ["Trend (log)", "Seasonal", "Remainder"], [NAVY, TEAL, GREY]):
    a.plot(s, color=c, lw=1.3); a.set_ylabel(t)
fig.tight_layout(); fig.savefig("figs/stl.png", dpi=200); plt.close()
sa = stl.seasonal.groupby(stl.seasonal.index.month).mean()
out["seasonal_strength"] = float(max(0, 1 - stl.resid.var() / (stl.resid + stl.seasonal).var()))
out["trend_strength"] = float(max(0, 1 - stl.resid.var() / (stl.resid + stl.trend).var()))
mm = y.groupby(y.index.month).mean()
out["peak_month"], out["trough_month"] = int(mm.idxmax()), int(mm.idxmin())

fig, axs = plt.subplots(1, 3, figsize=(12, 3.8))
dd = np.log(y).diff().diff(12).dropna()
plot_acf(np.log(y), lags=48, ax=axs[0], color=NAVY, title="ACF: log series")
plot_acf(dd, lags=48, ax=axs[1], color=TEAL, title="ACF: after d=1, D=1")
plot_pacf(dd, lags=48, ax=axs[2], color=ORANGE, title="PACF: after d=1, D=1", method="ywm")
fig.tight_layout(); fig.savefig("figs/acf_explore.png", dpi=200); plt.close()
out["adf_level_p"] = float(adfuller(np.log(y))[1]); out["adf_diff_p"] = float(adfuller(dd)[1])

# month x year heat/seasonal subseries
piv = y.groupby([y.index.year, y.index.month]).sum().unstack()
fig, ax = plt.subplots(figsize=(8, 5.4))
cm = plt.cm.viridis(np.linspace(0, 1, len(piv)))
for (yr, row), c in zip(piv.iterrows(), cm): ax.plot(range(1, 13), row.values, color=c, lw=1.2)
ax.set_xticks(range(1, 13)); ax.set_xticklabels(list("JFMAMJJASOND")); ax.set_ylabel("Billion kWh")
sm = plt.cm.ScalarMappable(cmap="viridis", norm=plt.Normalize(piv.index.min(), piv.index.max()))
fig.colorbar(sm, ax=ax, label="Year"); fig.tight_layout(); fig.savefig("figs/seasonal.png", dpi=200); plt.close()

# ---------- models ----------
def mape(a, f): return float(np.mean(np.abs((a - f) / a)) * 100)
def rmse(a, f): return float(np.sqrt(np.mean((a - f) ** 2)))
def mae(a, f): return float(np.mean(np.abs(a - f)))

def fit_hw(tr):
    best = None
    for trend, damped, seas in itertools.product([None, "add"], [False, True], ["add", "mul"]):
        if trend is None and damped: continue
        try:
            m = ExponentialSmoothing(tr, trend=trend, damped_trend=damped, seasonal=seas, seasonal_periods=12,
                                     initialization_method="estimated").fit()
            if best is None or m.aicc < best[0].aicc: best = (m, (trend, damped, seas))
        except Exception: pass
    return best

def fit_sarima(tr, log=True):
    z = np.log(tr) if log else tr
    best = None
    for p, q, P, Q in itertools.product(range(3), range(3), range(2), range(2)):
        try:
            m = SARIMAX(z, order=(p, 1, q), seasonal_order=(P, 1, Q, 12), enforce_stationarity=False,
                        enforce_invertibility=False).fit(disp=False, maxiter=200)
            if best is None or m.aic < best[0].aic: best = (m, (p, 1, q, P, 1, Q))
        except Exception: pass
    return best

def sn(tr, h): return pd.Series(np.tile(tr.values[-12:], int(np.ceil(h / 12)))[:h])
def sn_drift(tr, h):
    d = (tr.iloc[-12:].mean() - tr.iloc[-24:-12].mean()) / 12 * 12  # yearly level change
    base = tr.values[-12:]
    return pd.Series([base[i % 12] + d * (i // 12 + 1) for i in range(h)])

res = {}
fc = {}
fc["Seasonal naive"] = pd.Series(sn(train, H).values, index=test.index)
fc["Seasonal naive + drift"] = pd.Series(sn_drift(train, H).values, index=test.index)
hw, hw_spec = fit_hw(train)
fc["Holt-Winters (ETS)"] = hw.forecast(H)
sar, sar_spec = fit_sarima(train)
fc["SARIMA"] = np.exp(sar.get_forecast(H).predicted_mean)
fc["SARIMA"].index = test.index
for k, v in fc.items():
    res[k] = dict(RMSE=rmse(test, v), MAE=mae(test, v), MAPE=mape(test, v))
res["Holt-Winters (ETS)"].update(AICc=float(hw.aicc), spec=str(hw_spec))
# SARIMA AIC is on log scale -> convert to original-scale comparable via Jacobian: AIC_orig = AIC_log + 2*sum(log y)
res["SARIMA"].update(AIC_logscale=float(sar.aic), spec=str(sar_spec))
out["metrics"] = res

# rolling-origin check (3 origins, 12-month horizon) for robustness
roll = {k: [] for k in fc}; rollr = {k: [] for k in fc}
for k_off in [24, 12, 0]:
    tr_ = y.iloc[:len(y) - H - k_off]; te_ = y.iloc[len(y) - H - k_off: len(y) - k_off]
    pp = {"Seasonal naive": sn(tr_, H).values, "Seasonal naive + drift": sn_drift(tr_, H).values}
    pp["Holt-Winters (ETS)"] = ExponentialSmoothing(tr_, trend=hw_spec[0], damped_trend=hw_spec[1], seasonal=hw_spec[2],
                                seasonal_periods=12, initialization_method="estimated").fit().forecast(H).values
    s_ = SARIMAX(np.log(tr_), order=sar_spec[:3], seasonal_order=sar_spec[3:] + (12,), enforce_stationarity=False,
                 enforce_invertibility=False).fit(disp=False, maxiter=200)
    pp["SARIMA"] = np.exp(s_.get_forecast(H).predicted_mean).values
    for k in roll: roll[k].append(mape(te_.values, pp[k])); rollr[k].append(rmse(te_.values, pp[k]))
out["rolling_mape"] = {k: [float(x) for x in v] for k, v in roll.items()}
out["rolling_mape_mean"] = {k: float(np.mean(v)) for k, v in roll.items()}
out["rolling_rmse"] = {k: [float(x) for x in v] for k, v in rollr.items()}
out["rolling_rmse_mean"] = {k: float(np.mean(v)) for k, v in rollr.items()}

pd.DataFrame(fc).assign(actual=test).to_csv("holdout_forecasts.csv", float_format="%.2f")
y.rename("billion_kwh").to_csv("series_2001_2026.csv", float_format="%.3f")
# forecast plot (holdout)
fig, ax = plt.subplots(figsize=(11, 4.2))
ax.plot(y["2024-06":], color=NAVY, lw=3, label="Actual", zorder=1)
cols = {"Seasonal naive": GREY, "Seasonal naive + drift": "#B08D57", "Holt-Winters (ETS)": ORANGE, "SARIMA": TEAL}
for k, v in fc.items(): ax.plot(v, color=cols[k], lw=1.5, ls="--", label=k, zorder=5)
ax.axvline(test.index[0], color="k", lw=.8, ls=":"); ax.set_ylabel("Billion kWh per month")
ax.legend(frameon=False, ncol=3, fontsize=9, loc="upper left"); fig.tight_layout(); fig.savefig("figs/holdout.png", dpi=200); plt.close()

# ---------- residual analysis ----------
resid = {"Holt-Winters (ETS)": (hw.resid), "SARIMA": (sar.resid.iloc[26:])}
out["ljung"] = {}
import matplotlib.dates as mdates
fig, axs = plt.subplots(2, 3, figsize=(9, 4.8))
for i, (k, r) in enumerate(resid.items()):
    r = r.dropna(); lb = acorr_ljungbox(r, lags=[12, 24], model_df=0)
    out["ljung"][k] = {"p12": float(lb["lb_pvalue"].iloc[0]), "p24": float(lb["lb_pvalue"].iloc[1]),
                       "mean": float(r.mean()), "sd": float(r.std())}
    axs[i, 0].plot(r, color=[ORANGE, TEAL][i], lw=1); axs[i, 0].axhline(0, color="k", lw=.7); axs[i, 0].set_title(f"{k.split(' (')[0]}: residuals", fontsize=10)
    axs[i, 0].xaxis.set_major_locator(mdates.YearLocator(8)); axs[i, 0].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    plot_acf(r, lags=36, ax=axs[i, 1], color=[ORANGE, TEAL][i], title=f"{k.split(' (')[0]}: residual ACF")
    axs[i, 2].hist(r, bins=25, color=[ORANGE, TEAL][i], alpha=.85); axs[i, 2].set_title("Histogram")
fig.tight_layout(); fig.savefig("figs/residuals.png", dpi=200); plt.close()

# SARIMA coefficient table
out["sarima_params"] = {n: [float(v), float(p)] for n, v, p in zip(sar.param_names, sar.params, sar.pvalues)}

# ---------- final model: pick by holdout RMSE+MAPE then refit on all data ----------
rank = sorted(res, key=lambda k: out["rolling_rmse_mean"][k])
out["rank_by_rmse"] = rank
best = rank[0]; out["chosen"] = best
fidx = pd.date_range(y.index[-1] + pd.offsets.MonthBegin(1), periods=12, freq="MS")
if best == "SARIMA":
    m = SARIMAX(np.log(y), order=sar_spec[:3], seasonal_order=sar_spec[3:] + (12,), enforce_stationarity=False,
                enforce_invertibility=False).fit(disp=False, maxiter=200)
    f = m.get_forecast(12); ci = f.conf_int(alpha=.2); ci95 = f.conf_int(alpha=.05)
    pt = np.exp(f.predicted_mean); lo, hi = np.exp(ci.iloc[:, 0]), np.exp(ci.iloc[:, 1]); lo95, hi95 = np.exp(ci95.iloc[:, 0]), np.exp(ci95.iloc[:, 1])
    # ljung for refit
    out["final_ljung_p12"] = float(acorr_ljungbox(m.resid.iloc[26:], lags=[12], model_df=0)["lb_pvalue"].iloc[0])
else:
    m = ExponentialSmoothing(y, trend=hw_spec[0], damped_trend=hw_spec[1], seasonal=hw_spec[2], seasonal_periods=12,
                             initialization_method="estimated").fit()
    pt = m.forecast(12); s = m.resid.std()
    lo, hi = pt - 1.2816 * s, pt + 1.2816 * s; lo95, hi95 = pt - 1.96 * s, pt + 1.96 * s
for s_ in (pt, lo, hi, lo95, hi95): s_.index = fidx
fdf = pd.DataFrame({"forecast": pt, "lo80": lo, "hi80": hi, "lo95": lo95, "hi95": hi95})
fdf.to_csv("forecast_next12.csv", float_format="%.2f")
out["forecast"] = {str(d.date()): [float(v) for v in r] for d, r in fdf.iterrows()}
last12 = y.iloc[-12:]; out["last12_total"] = float(last12.sum()); out["fc12_total"] = float(pt.sum())
out["growth_pct"] = float((pt.sum() / last12.sum() - 1) * 100)
out["fc_peak_month"] = str(pt.idxmax().date()); out["fc_peak"] = float(pt.max())
out["prior_summer_peak"] = float(y["2025-07"].iloc[0]); out["last_peak_2026"] = float(y["2026-07"].iloc[0])
out["yoy_peak_growth_2026"] = float(y["2026-07"].iloc[0] / y["2025-07"].iloc[0] * 100 - 100)

fig, ax = plt.subplots(figsize=(11, 4.2))
ax.plot(y["2023":], color=NAVY, lw=1.8, label="Actual")
ax.plot(pt, color=ORANGE, lw=2.2, label=f"{best} forecast")
ax.fill_between(fidx, lo95, hi95, color=ORANGE, alpha=.15, label="95% interval")
ax.fill_between(fidx, lo, hi, color=ORANGE, alpha=.3, label="80% interval")
ax.set_ylabel("Billion kWh per month"); ax.legend(frameon=False, ncol=4, loc="upper left")
fig.tight_layout(); fig.savefig("figs/forecast.png", dpi=200); plt.close()

# data checks
out["covid_dip_pct"] = float((y["2020-04":"2020-06"].sum() / y["2019-04":"2019-06"].sum() - 1) * 100)
ann = y.groupby(y.index.year).sum(); ann = ann[ann.index <= 2025]
out["cagr_2007_2019"] = float((ann[2019] / ann[2007]) ** (1 / 12) * 100 - 100)
out["cagr_2019_2025"] = float((ann[2025] / ann[2019]) ** (1 / 6) * 100 - 100)
out["ann"] = {int(k): float(v) for k, v in ann.items()}
json.dump(out, open("results.json", "w"), indent=1, default=str)
print(json.dumps({k: out[k] for k in out if k not in ("forecast", "ann", "sarima_params")}, indent=1, default=str))

# compact chart for the 1-page memo
fig, ax = plt.subplots(figsize=(7.2, 2.3))
ax.plot(y["2024-08":], color=NAVY, lw=2, label="Actual (EIA)")
ax.plot(pt, color=ORANGE, lw=2, label="SARIMA forecast")
ax.fill_between(fidx, lo, hi, color=ORANGE, alpha=.25, label="80% interval")
ax.set_ylabel("bn kWh / month", fontsize=9); ax.tick_params(labelsize=9); ax.set_ylim(280, 455)
ax.legend(frameon=False, ncol=3, fontsize=9, loc="upper left"); fig.tight_layout(); fig.savefig("figs/forecast_memo.png", dpi=220); plt.close()
